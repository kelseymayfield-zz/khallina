angular.module('khallinaApp')
  .controller('CreateCtrl', function($scope) {
    'use strict';
    $scope.module = {
      elem: {},
      intm: {},
      adv: {}
    };
  });